python3 ansi2latex.py < log.txt > log.tex
